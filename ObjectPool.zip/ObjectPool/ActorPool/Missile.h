#pragma once
#include "Actor.h"

class Missile : public Actor
{
public:
	Missile() ;
	~Missile();
	void Update() ;
};


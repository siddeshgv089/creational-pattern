#pragma once
class Product
{
public:
	virtual void Operation() = 0 ;
	virtual ~Product() = default ;
};


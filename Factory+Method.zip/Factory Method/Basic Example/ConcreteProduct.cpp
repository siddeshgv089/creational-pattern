#include "ConcreteProduct.h"
#include <iostream>

void ConcreteProduct::Operation() {
	std::cout << __FUNCSIG__ << std::endl; 
}

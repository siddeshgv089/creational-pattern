#pragma once
#include "Product.h"
class ConcreteProduct2 :
	public Product
{

public:
	void Operation() override;
};


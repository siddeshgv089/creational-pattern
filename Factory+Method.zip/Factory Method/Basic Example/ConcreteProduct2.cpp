#include "ConcreteProduct2.h"
#include <iostream>

void ConcreteProduct2::Operation() {
	std::cout << __FUNCSIG__ << std::endl; 
}

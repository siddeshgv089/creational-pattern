#include "Creator.h"
#include "ConcreteCreator.h"
#include "ConcreteCreator2.h"

int main() {
	ConcreteCreator2 ct ;
	ct.AnOperation() ;
}

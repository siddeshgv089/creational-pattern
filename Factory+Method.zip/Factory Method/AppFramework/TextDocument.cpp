#include "TextDocument.h"
#include <iostream>

void TextDocument::Write() {
	std::cout << __FUNCSIG__ << std::endl; 
}

void TextDocument::Read() {
	std::cout << __FUNCSIG__ << std::endl; 
}

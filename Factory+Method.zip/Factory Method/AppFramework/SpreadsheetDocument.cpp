#include "SpreadsheetDocument.h"
#include <iostream>

void SpreadsheetDocument::Write() {
	std::cout << __FUNCSIG__ << std::endl; 
}

void SpreadsheetDocument::Read() {
	std::cout << __FUNCSIG__ << std::endl; 
}

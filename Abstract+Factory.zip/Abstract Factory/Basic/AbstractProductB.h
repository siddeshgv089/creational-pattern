#pragma once
class AbstractProductB
{
public:
	virtual void ProductB() = 0 ;
	virtual ~AbstractProductB() = default ;
};


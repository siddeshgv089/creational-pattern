#pragma once
class AbstractProductA
{
public:
	virtual void ProductA() = 0 ;
	virtual ~AbstractProductA() = default ;
};


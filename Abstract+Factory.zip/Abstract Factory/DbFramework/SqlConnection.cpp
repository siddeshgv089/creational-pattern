#include "SqlConnection.h"
#include <iostream>

void SqlConnection::Open() {
	std::cout << "[SqlConnection] Connection opened\n" ;
}

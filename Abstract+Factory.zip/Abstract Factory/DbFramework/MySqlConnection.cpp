#include "MySqlConnection.h"
#include <iostream>

void MySqlConnection::Open() {
	std::cout << "[MySqlConnection] Connection opened\n" ;
}
